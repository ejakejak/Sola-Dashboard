"""SOLA Phase 3-4 — commercial loop: Quotation → Order → Invoice → Payment (+ PDF).

Built ON the Phase-2 app: reuses generic require_permission() and audit() from
app.auth / app.db, and the existing schema tables (quotations, quotation_items,
orders, order_items, invoices, invoice_items, payments) — no DDL change.

Business rules enforced here (backend):
- Auto sequential numbers QUO/ORD/INV-<YYYY>-NNNN (year-fresh).
- A quotation converts ONCE into a sales order (status -> converted, locked).
- An invoice is generated FROM an order (one open invoice per order — no manual dupe).
- outstanding = grand_total - amount_paid, auto-recomputed on every payment;
  status -> paid when outstanding <= 0.
- Every write (create/status/convert/invoice/payment) is audited via audit().
"""
from datetime import date, timedelta

from flask import (
    Blueprint,
    abort,
    flash,
    g,
    redirect,
    render_template,
    request,
    send_file,
    url_for,
)

from .auth import require_permission
from .db import audit, get_db
from .invoice_pdf import render_invoice_pdf

QUOTE_BP = Blueprint("quotations", __name__, url_prefix="/quotations")
ORDER_BP = Blueprint("orders", __name__, url_prefix="/orders")
INVOICE_BP = Blueprint("invoices", __name__, url_prefix="/invoices")

QUO_STATUSES = ["draft", "sent", "approved", "rejected", "converted", "cancelled"]
ORD_STATUSES = ["pending", "confirmed", "in_production", "completed", "cancelled"]
INV_PRIORITY = ["low", "normal", "high", "urgent"]
INV_STATUSES = ["draft", "issued", "partially_paid", "paid", "overdue", "cancelled"]
PAY_METHODS = ["transfer", "cash", "qris", "other"]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _year():
    return date.today().strftime("%Y")


def _select_opts(query, params=()):
    db = get_db()
    return [dict(r) for r in db.execute(query, params).fetchall()]


def _money(v):
    try:
        return f"{int(round(float(v or 0))):,}".replace(",", ".")
    except (TypeError, ValueError):
        return "0"


def _next_number(prefix, table, col):
    """Return next '<PREFIX>-<YYYY>-NNNN' sequential value (year-fresh)."""
    db = get_db()
    pat = f"{prefix}-{_year()}-%"
    rows = db.execute(f"SELECT {col} FROM {table} WHERE {col} LIKE ?", (pat,)).fetchall()
    highest = 0
    for r in rows:
        tail = r[col].rsplit("-", 1)[-1]
        if tail.isdigit():
            highest = max(highest, int(tail))
    return f"{prefix}-{_year()}-{highest + 1:04d}"


def _fmt_number(value):
    try:
        return str(int(value)) if float(value) == int(float(value)) else f"{value:g}"
    except (TypeError, ValueError):
        return str(value)


def _compact(items):
    parts = []
    for k in ("product", "variant", "material", "color", "size", "decoration", "position", "spec"):
        if items.get(k):
            parts.append(str(items[k]))
    return " · ".join(parts)


def _order_item_description(db, oi):
    """Human line-item description (customer-facing, no cost data)."""
    row = db.execute(
        """
        SELECT p.product_name, v.variant_name, m.material_name, co.color_name,
               s.size_code, d.decoration_name, oi.decoration_position,
               oi.decoration_size, oi.notes, oi.quantity, oi.unit_price, oi.subtotal,
               u.unit_code
        FROM order_items oi
        LEFT JOIN products p ON p.product_id = oi.product_id
        LEFT JOIN product_variants v ON v.variant_id = oi.variant_id
        LEFT JOIN materials m ON m.material_id = oi.material_id
        LEFT JOIN colors co ON co.color_id = oi.color_id
        LEFT JOIN sizes s ON s.size_id = oi.size_id
        LEFT JOIN decorations d ON d.decoration_id = oi.decoration_id
        LEFT JOIN units u ON u.unit_id = oi.unit_id
        WHERE oi.order_item_id = ?
        """,
        (oi["order_item_id"],),
    ).fetchone()
    if row is None:
        return "Item"
    bit = []
    if row["product_name"]:
        bit.append(row["product_name"])
    if row["variant_name"]:
        bit.append(row["variant_name"])
    if row["material_name"]:
        bit.append(row["material_name"])
    if row["color_name"]:
        bit.append("Warna " + row["color_name"])
    if row["size_code"]:
        bit.append("Ukuran " + row["size_code"])
    if row["decoration_name"]:
        deco = row["decoration_name"]
        if row["decoration_position"]:
            deco += " (" + row["decoration_position"] + ")"
        if row["decoration_size"]:
            deco += " " + str(row["decoration_size"])
        bit.append("Bordir/Sablon: " + deco)
    if row["notes"]:
        bit.append("Catatan: " + str(row["notes"]))
    return " · ".join(bit) if bit else "Item"


# ---------------------------------------------------------------------------
# QUOTATION
# ---------------------------------------------------------------------------
@QUOTE_BP.route("/")
@require_permission("quotation.view")
def list():
    q = request.args.get("q", "").strip()
    db = get_db()
    rows = db.execute(
        """
        SELECT q.*, c.name AS customer_name,
               (SELECT COUNT(*) FROM quotation_items qi WHERE qi.quotation_id = q.quotation_id) AS item_count
        FROM quotations q LEFT JOIN customers c ON c.customer_id = q.customer_id
        """ + (f"WHERE q.quotation_number LIKE ? OR c.name LIKE ?" if q else "") + """
        ORDER BY q.quotation_id DESC
        """,
        ([f"%{q}%", f"%{q}%"] if q else []),
    ).fetchall()
    return render_template("quotation_list.html", rows=rows, q=q,
                           can_create=_has("quotation.create"), can_update=_has("quotation.update"))


@QUOTE_BP.route("/new", methods=["GET", "POST"])
@require_permission("quotation.create")
def create():
    db = get_db()
    customers = _select_opts("SELECT * FROM customers ORDER BY name")
    materials = _select_opts("SELECT * FROM materials WHERE status='active' ORDER BY material_name")
    products = _select_opts("SELECT * FROM products ORDER BY product_name")
    variants = _select_opts("SELECT * FROM product_variants ORDER BY variant_name")
    decorations = _select_opts("SELECT * FROM decorations WHERE status='active' ORDER BY decoration_name")
    units = _select_opts("SELECT * FROM units ORDER BY unit_code")

    if request.method == "POST":
        data, errors = _collect_quotation()
        if not errors:
            num = _next_number("QUO", "quotations", "quotation_number")
            cur = db.execute(
                "INSERT INTO quotations (quotation_number, customer_id, quotation_date, valid_until,"
                " subtotal, discount, tax, total, notes, status) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (num, data["customer_id"], data["quotation_date"], data["valid_until"],
                 data["subtotal"], data["discount"], data["tax"], data["total"],
                 data["notes"], "draft"),
            )
            qid = cur.lastrowid
            for it in data["items"]:
                db.execute(
                    "INSERT INTO quotation_items (quotation_id, product_id, variant_id, material_id,"
                    " decoration_id, specification, quantity, unit_id, unit_price, subtotal)"
                    " VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (qid, it["product_id"], it["variant_id"], it["material_id"], it["decoration_id"],
                     it["specification"], it["quantity"], it["unit_id"], it["unit_price"], it["subtotal"]),
                )
            db.commit()
            audit(g.current_user["user_id"], "CREATE", "quotation", entity_id=qid,
                  new_value={"quotation_number": num, "customer_id": data["customer_id"], "total": data["total"]})
            flash(f"Quotation {num} created.", "success")
            return redirect(url_for("quotations.detail", qid=qid))
        for e in errors:
            flash(e, "danger")

    return render_template("quotation_form.html", customers=customers, materials=materials,
                           products=products, variants=variants, decorations=decorations,
                           units=units, modes=QUO_STATUSES, form=dict(request.form))


def _collect_quotation():
    db = get_db()
    errors = []
    customer_id = request.form.get("customer_id") or None
    if customer_id is None:
        errors.append("Customer is required.")
    quotation_date = request.form.get("quotation_date") or date.today().isoformat()
    valid_until = request.form.get("valid_until") or None
    discount = _float_or(request.form.get("discount"), 0.0)
    tax = _float_or(request.form.get("tax"), 0.0)
    notes = request.form.get("notes") or None

    item_rows = []
    names = request.form.getlist("item_product[]")
    if not names:
        errors.append("Add at least one line item.")
    for idx, _pid in enumerate(names):
        qty = _float_or(_at(request.form, f"item_qty[]", idx), None)
        price = _float_or(_at(request.form, f"item_price[]", idx), 0.0)
        if qty is None or qty <= 0:
            errors.append(f"Item {idx + 1}: quantity must be a positive number.")
            continue
        material = _at(request.form, f"item_material[]", idx) or None
        price = price if price and price > 0 else (_catalog_price(material) or 0)
        item_rows.append({
            "product_id": _at(request.form, f"item_product[]", idx) or None,
            "variant_id": _at(request.form, f"item_variant[]", idx) or None,
            "material_id": material,
            "decoration_id": _at(request.form, f"item_decoration[]", idx) or None,
            "specification": _at(request.form, f"item_spec[]", idx) or None,
            "quantity": qty,
            "unit_id": _at(request.form, f"item_unit[]", idx) or None,
            "unit_price": price,
            "subtotal": round(qty * price, 2),
        })
    subtotal = round(sum(i["subtotal"] for i in item_rows), 2)
    total = round(subtotal - discount + tax, 2)
    data = {
        "customer_id": int(customer_id) if customer_id else None,
        "quotation_date": quotation_date, "valid_until": valid_until,
        "discount": discount, "tax": tax, "notes": notes,
        "subtotal": subtotal, "total": total,
        "items": item_rows,
    }
    return data, errors


@QUOTE_BP.route("/<int:qid>")
@require_permission("quotation.view")
def detail(qid):
    db = get_db()
    q = db.execute(
        "SELECT q.*, c.name AS customer_name, c.company_name, c.phone, c.address"
        " FROM quotations q LEFT JOIN customers c ON c.customer_id = q.customer_id WHERE q.quotation_id = ?",
        (qid,),
    ).fetchone()
    if q is None:
        abort(404)
    items = db.execute(
        """
        SELECT qi.*, m.material_name, p.product_name, v.variant_name, d.decoration_name, u.unit_code
        FROM quotation_items qi
        LEFT JOIN materials m ON m.material_id = qi.material_id
        LEFT JOIN products p ON p.product_id = qi.product_id
        LEFT JOIN product_variants v ON v.variant_id = qi.variant_id
        LEFT JOIN decorations d ON d.decoration_id = qi.decoration_id
        LEFT JOIN units u ON u.unit_id = qi.unit_id
        WHERE qi.quotation_id = ? ORDER BY qi.quotation_item_id
        """,
        (qid,),
    ).fetchall()
    order = db.execute("SELECT * FROM orders WHERE quotation_id = ?", (qid,)).fetchone()
    return render_template("quotation_detail.html", q=q, items=items, order=order,
                           modes=QUO_STATUSES, c_create=_has("quotation.create"),
                           c_update=_has("quotation.update"), c_convert=_has("quotation.convert"))


@QUOTE_BP.route("/<int:qid>/status", methods=["POST"])
@require_permission("quotation.update")
def set_status(qid):
    db = get_db()
    q = db.execute("SELECT * FROM quotations WHERE quotation_id = ?", (qid,)).fetchone()
    if q is None:
        abort(404)
    status = request.form.get("status")
    if status not in QUO_STATUSES or status == "converted":
        flash("Invalid status.", "danger")
        return redirect(url_for("quotations.detail", qid=qid))
    allowed = {"draft", "sent", "approved", "rejected", "cancelled"}  # converted only via convert()
    if status not in allowed:
        flash("Invalid status transition.", "danger")
        return redirect(url_for("quotations.detail", qid=qid))
    db.execute("UPDATE quotations SET status = ? WHERE quotation_id = ?", (status, qid))
    db.commit()
    audit(g.current_user["user_id"], "UPDATE", "quotation", entity_id=qid,
          old_value={"status": q["status"]}, new_value={"status": status})
    flash(f"Quotation {q['quotation_number']} marked {status}.", "success")
    return redirect(url_for("quotations.detail", qid=qid))


@QUOTE_BP.route("/<int:qid>/convert", methods=["POST"])
@require_permission("quotation.convert")
def convert(qid):
    db = get_db()
    q = db.execute("SELECT * FROM quotations WHERE quotation_id = ?", (qid,)).fetchone()
    if q is None:
        abort(404)
    if q["status"] != "approved":
        flash("Only an APPROVED quotation can be converted to an order.", "danger")
        return redirect(url_for("quotations.detail", qid=qid))
    existing = db.execute("SELECT order_id FROM orders WHERE quotation_id = ?", (qid,)).fetchone()
    if existing:
        flash("This quotation is already converted to an order.", "danger")
        return redirect(url_for("quotations.detail", qid=qid))
    q_items = db.execute(
        "SELECT * FROM quotation_items WHERE quotation_id = ?", (qid,)
    ).fetchall()
    if not q_items:
        flash("Quotation has no line items; cannot convert.", "danger")
        return redirect(url_for("quotations.detail", qid=qid))

    num = _next_number("ORD", "orders", "order_number")
    deadline = request.form.get("deadline") or None
    priority = request.form.get("priority") or "normal"
    if priority not in INV_PRIORITY:
        priority = "normal"
    grand_total = round(float(q["total"] or 0), 2)
    cur = db.execute(
        "INSERT INTO orders (order_number, customer_id, quotation_id, order_date, deadline, status,"
        " priority, subtotal, discount, tax, grand_total, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (num, q["customer_id"], qid, date.today().isoformat(), deadline, "confirmed",
         priority, q["subtotal"], q["discount"], q["tax"], grand_total, q["notes"]),
    )
    oid = cur.lastrowid
    for qi in q_items:
        db.execute(
            "INSERT INTO order_items (order_id, product_id, variant_id, material_id, decoration_id,"
            " decoration_position, decoration_size, size_id, quantity, unit_id, unit_price, subtotal, notes)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (oid, qi["product_id"], qi["variant_id"], qi["material_id"], qi["decoration_id"],
             None, None, None, qi["quantity"], qi["unit_id"], qi["unit_price"], qi["subtotal"],
             qi["specification"]),
        )
    db.execute("UPDATE quotations SET status = 'converted' WHERE quotation_id = ?", (qid,))
    db.commit()
    audit(g.current_user["user_id"], "CONVERT", "quotation", entity_id=qid,
          new_value={"order_id": oid, "order_number": num})
    audit(g.current_user["user_id"], "CREATE", "order", entity_id=oid,
          new_value={"order_number": num, "quotation_id": qid, "grand_total": grand_total})
    flash(f"Quotation {q['quotation_number']} converted to {num}.", "success")
    return redirect(url_for("orders.detail", oid=oid))


# ---------------------------------------------------------------------------
# ORDER
# ---------------------------------------------------------------------------
@ORDER_BP.route("/")
@require_permission("order.view")
def list():
    q = request.args.get("q", "").strip()
    db = get_db()
    rows = db.execute(
        """
        SELECT o.*, c.name AS customer_name,
               (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.order_id) AS item_count
        FROM orders o LEFT JOIN customers c ON c.customer_id = o.customer_id
        """ + (f"WHERE o.order_number LIKE ? OR c.name LIKE ?" if q else "") + """
        ORDER BY o.order_id DESC
        """,
        ([f"%{q}%", f"%{q}%"] if q else []),
    ).fetchall()
    return render_template("order_list.html", rows=rows, q=q,
                           can_create=_has("order.create"))


@ORDER_BP.route("/new", methods=["GET", "POST"])
@require_permission("order.create")
def create():
    db = get_db()
    customers = _select_opts("SELECT * FROM customers ORDER BY name")
    materials = _select_opts("SELECT * FROM materials WHERE status='active' ORDER BY material_name")
    products = _select_opts("SELECT * FROM products ORDER BY product_name")
    variants = _select_opts("SELECT * FROM product_variants ORDER BY variant_name")
    decorations = _select_opts("SELECT * FROM decorations WHERE status='active' ORDER BY decoration_name")
    colors = _select_opts("SELECT * FROM colors ORDER BY color_name")
    sizes = _select_opts("SELECT * FROM sizes ORDER BY sort_order, size_code")
    units = _select_opts("SELECT * FROM units ORDER BY unit_code")

    if request.method == "POST":
        data, errors = _collect_order()
        if not errors:
            num = _next_number("ORD", "orders", "order_number")
            cur = db.execute(
                "INSERT INTO orders (order_number, customer_id, order_date, deadline, status, priority,"
                " subtotal, discount, tax, grand_total, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (num, data["customer_id"], date.today().isoformat(), data["deadline"], "confirmed",
                 data["priority"], data["subtotal"], data["discount"], data["tax"], data["total"], data["notes"]),
            )
            oid = cur.lastrowid
            for it in data["items"]:
                db.execute(
                    "INSERT INTO order_items (order_id, product_id, variant_id, material_id, color_id,"
                    " decoration_id, decoration_position, decoration_size, size_id, quantity, unit_id,"
                    " unit_price, subtotal, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (oid, it["product_id"], it["variant_id"], it["material_id"], it["color_id"],
                     it["decoration_id"], it["dec_position"], it["dec_size"], it["size_id"],
                     it["quantity"], it["unit_id"], it["unit_price"], it["subtotal"], it["notes"]),
                )
            db.commit()
            audit(g.current_user["user_id"], "CREATE", "order", entity_id=oid,
                  new_value={"order_number": num, "customer_id": data["customer_id"], "grand_total": data["total"]})
            flash(f"Order {num} created.", "success")
            return redirect(url_for("orders.detail", oid=oid))
        for e in errors:
            flash(e, "danger")

    return render_template("order_form.html", customers=customers, materials=materials,
                           products=products, variants=variants, decorations=decorations,
                           colors=colors, sizes=sizes, units=units, priorities=INV_PRIORITY,
                           form=dict(request.form))


def _collect_order():
    errors = []
    customer_id = request.form.get("customer_id") or None
    if customer_id is None:
        errors.append("Customer is required.")
    deadline = request.form.get("deadline") or None
    priority = request.form.get("priority") or "normal"
    if priority not in INV_PRIORITY:
        priority = "normal"
    discount = _float_or(request.form.get("discount"), 0.0)
    tax = _float_or(request.form.get("tax"), 0.0)
    notes = request.form.get("notes") or None

    item_rows = []
    if not request.form.getlist("item_product[]"):
        errors.append("Add at least one line item.")
    for idx, _pid in enumerate(request.form.getlist("item_product[]")):
        qty = _float_or(_at(request.form, f"item_qty[]", idx), None)
        price = _float_or(_at(request.form, f"item_price[]", idx), 0.0)
        if qty is None or qty <= 0:
            errors.append(f"Item {idx + 1}: quantity must be a positive number.")
            continue
        material = _at(request.form, f"item_material[]", idx) or None
        price = price if price and price > 0 else (_catalog_price(material) or 0)
        item_rows.append({
            "product_id": _at(request.form, f"item_product[]", idx) or None,
            "variant_id": _at(request.form, f"item_variant[]", idx) or None,
            "material_id": material,
            "color_id": _at(request.form, f"item_color[]", idx) or None,
            "decoration_id": _at(request.form, f"item_decoration[]", idx) or None,
            "dec_position": _at(request.form, f"item_position[]", idx) or None,
            "dec_size": _at(request.form, f"item_decsize[]", idx) or None,
            "size_id": _at(request.form, f"item_size[]", idx) or None,
            "quantity": qty,
            "unit_id": _at(request.form, f"item_unit[]", idx) or None,
            "unit_price": price,
            "subtotal": round(qty * price, 2),
            "notes": _at(request.form, f"item_notes[]", idx) or None,
        })
    subtotal = round(sum(i["subtotal"] for i in item_rows), 2)
    total = round(subtotal - discount + tax, 2)
    data = {
        "customer_id": int(customer_id) if customer_id else None,
        "deadline": deadline, "priority": priority,
        "discount": discount, "tax": tax, "notes": notes,
        "subtotal": subtotal, "total": total, "items": item_rows,
    }
    return data, errors


@ORDER_BP.route("/<int:oid>")
@require_permission("order.view")
def detail(oid):
    db = get_db()
    o = db.execute(
        "SELECT o.*, c.name AS customer_name, c.company_name, c.phone, c.address"
        " FROM orders o LEFT JOIN customers c ON c.customer_id = o.customer_id WHERE o.order_id = ?",
        (oid,),
    ).fetchone()
    if o is None:
        abort(404)
    items = db.execute(
        """
        SELECT oi.*, m.material_name, p.product_name, v.variant_name, d.decoration_name,
               co.color_name, s.size_code, u.unit_code
        FROM order_items oi
        LEFT JOIN materials m ON m.material_id = oi.material_id
        LEFT JOIN products p ON p.product_id = oi.product_id
        LEFT JOIN product_variants v ON v.variant_id = oi.variant_id
        LEFT JOIN decorations d ON d.decoration_id = oi.decoration_id
        LEFT JOIN colors co ON co.color_id = oi.color_id
        LEFT JOIN sizes s ON s.size_id = oi.size_id
        LEFT JOIN units u ON u.unit_id = oi.unit_id
        WHERE oi.order_id = ? ORDER BY oi.order_item_id
        """,
        (oid,),
    ).fetchall()
    invoices = db.execute("SELECT * FROM invoices WHERE order_id = ? ORDER BY invoice_id", (oid,)).fetchall()
    quotation = db.execute("SELECT * FROM quotations WHERE quotation_id = ?", (o["quotation_id"],)).fetchone() if o["quotation_id"] else None
    return render_template("order_detail.html", o=o, items=items, invoices=invoices,
                           quotation=quotation, priorities=INV_PRIORITY,
                           c_invoice=_has("invoice.create"))


# ---------------------------------------------------------------------------
# INVOICE
# ---------------------------------------------------------------------------
@INVOICE_BP.route("/")
@require_permission("invoice.view")
def list():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    db = get_db()
    conds, params = [], []
    if q:
        conds.append("(i.invoice_number LIKE ? OR c.name LIKE ? OR c.company_name LIKE ?)")
        params += [f"%{q}%"] * 3
    if status:
        conds.append("i.status = ?")
        params.append(status)
    where = ("WHERE " + " AND ".join(conds)) if conds else ""
    rows = db.execute(
        "SELECT i.*, o.order_number, c.name AS customer_name, o.status AS order_status"
        " FROM invoices i LEFT JOIN orders o ON o.order_id = i.order_id"
        " LEFT JOIN customers c ON c.customer_id = i.customer_id"
        f" {where} ORDER BY i.invoice_id DESC",
        params,
    ).fetchall()
    return render_template("invoice_list.html", rows=rows, q=q, status=status,
                           statuses=INV_STATUSES, can_print=_has("invoice.view"))


@INVOICE_BP.route("/from-order/<int:oid>", methods=["POST"])
@require_permission("invoice.create")
def create_from_order(oid):
    db = get_db()
    o = db.execute("SELECT * FROM orders WHERE order_id = ?", (oid,)).fetchone()
    if o is None:
        abort(404)
    if o["status"] in ("cancelled", "pending"):
        flash(f"Cannot invoice an order with status '{o['status']}'.", "danger")
        return redirect(url_for("orders.detail", oid=oid))
    dup = db.execute(
        "SELECT invoice_id FROM invoices WHERE order_id = ? AND status != 'cancelled'", (oid,)
    ).fetchone()
    if dup:
        flash("An active invoice already exists for this order.", "danger")
        return redirect(url_for("orders.detail", oid=oid))

    num = _next_number("INV", "invoices", "invoice_number")
    grand_total = round(float(o["grand_total"] or 0), 2)
    due = date.today() + timedelta(days=14)
    cur = db.execute(
        "INSERT INTO invoices (invoice_number, order_id, customer_id, invoice_date, due_date,"
        " subtotal, discount, tax, grand_total, amount_paid, outstanding, status)"
        " VALUES (?,?,?,?,?,?,?,?,?,0,?, 'draft')",
        (num, oid, o["customer_id"], date.today().isoformat(), due.isoformat(),
         o["subtotal"], o["discount"], o["tax"], grand_total, grand_total),
    )
    iid = cur.lastrowid
    o_items = db.execute("SELECT * FROM order_items WHERE order_id = ?", (oid,)).fetchall()
    for oi in o_items:
        desc = _order_item_description(db, oi)
        db.execute(
            "INSERT INTO invoice_items (invoice_id, order_item_id, description, quantity, unit_id,"
            " unit_price, subtotal) VALUES (?,?,?,?,?,?,?)",
            (iid, oi["order_item_id"], desc, oi["quantity"], oi["unit_id"],
             oi["unit_price"], oi["subtotal"]),
        )
    db.commit()
    audit(g.current_user["user_id"], "CREATE", "invoice", entity_id=iid,
          new_value={"invoice_number": num, "order_id": oid, "grand_total": grand_total,
                     "outstanding": grand_total})
    flash(f"Invoice {num} generated from order {o['order_number']}.", "success")
    return redirect(url_for("invoices.detail", iid=iid))


@INVOICE_BP.route("/<int:iid>")
@require_permission("invoice.view")
def detail(iid):
    db = get_db()
    i = db.execute(
        "SELECT i.*, o.order_number, c.name AS customer_name, c.company_name, c.phone, c.address"
        " FROM invoices i LEFT JOIN orders o ON o.order_id = i.order_id"
        " LEFT JOIN customers c ON c.customer_id = i.customer_id WHERE i.invoice_id = ?",
        (iid,),
    ).fetchone()
    if i is None:
        abort(404)
    items = db.execute(
        "SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY invoice_item_id", (iid,)
    ).fetchall()
    payments = db.execute(
        "SELECT py.*, u.username FROM payments py LEFT JOIN users u ON u.user_id = py.created_by"
        " WHERE py.invoice_id = ? ORDER BY py.payment_id", (iid,)
    ).fetchall()
    return render_template("invoice_detail.html", i=i, items=items, payments=payments,
                           methods=PAY_METHODS, statuses=INV_STATUSES,
                           c_payment=_has("invoice.payment"), c_update=_has("invoice.update"))


@INVOICE_BP.route("/<int:iid>/status", methods=["POST"])
@require_permission("invoice.update")
def set_status(iid):
    db = get_db()
    i = db.execute("SELECT * FROM invoices WHERE invoice_id = ?", (iid,)).fetchone()
    if i is None:
        abort(404)
    status = request.form.get("status")
    if status not in ("issued", "cancelled"):
        flash("Only 'issued' or 'cancelled' can be set manually.", "danger")
        return redirect(url_for("invoices.detail", iid=iid))
    db.execute("UPDATE invoices SET status = ? WHERE invoice_id = ?", (status, iid))
    db.commit()
    audit(g.current_user["user_id"], "UPDATE", "invoice", entity_id=iid,
          old_value={"status": i["status"]}, new_value={"status": status, "status_set": "manual"})
    flash(f"Invoice {i['invoice_number']} marked {status}.", "success")
    return redirect(url_for("invoices.detail", iid=iid))


@INVOICE_BP.route("/<int:iid>/payment", methods=["POST"])
@require_permission("invoice.payment")
def add_payment(iid):
    db = get_db()
    i = db.execute("SELECT * FROM invoices WHERE invoice_id = ?", (iid,)).fetchone()
    if i is None:
        abort(404)
    if i["status"] == "cancelled":
        flash("Cannot record payment on a cancelled invoice.", "danger")
        return redirect(url_for("invoices.detail", iid=iid))
    if i["status"] == "draft":
        flash("Issue the invoice before recording payment.", "danger")
        return redirect(url_for("invoices.detail", iid=iid))
    amount = _float_or(request.form.get("amount"), None)
    if amount is None or amount <= 0:
        flash("Payment amount must be a positive number.", "danger")
        return redirect(url_for("invoices.detail", iid=iid))
    method = request.form.get("method") or "transfer"
    if method not in PAY_METHODS:
        method = "transfer"
    reference = request.form.get("reference") or None
    notes = request.form.get("notes") or None

    cur = db.execute(
        "INSERT INTO payments (invoice_id, payment_date, amount, method, reference, notes, created_by)"
        " VALUES (?,?,?,?,?,?,?)",
        (iid, (request.form.get("payment_date") or date.today().isoformat()),
         amount, method, reference, notes, g.current_user["user_id"]),
    )
    paid = round(float(db.execute(
        "SELECT COALESCE(SUM(amount),0) FROM payments WHERE invoice_id = ?", (iid,)
    ).fetchone()[0]), 2)
    outstanding = round(float(i["grand_total"] or 0) - paid, 2)
    if outstanding <= 0.005:
        status = "paid"
    elif paid > 0:
        status = "partially_paid"
    else:
        status = i["status"]
    db.execute(
        "UPDATE invoices SET amount_paid = ?, outstanding = ?, status = ? WHERE invoice_id = ?",
        (paid, outstanding, status, iid),
    )
    db.commit()
    audit(g.current_user["user_id"], "CREATE", "payment", entity_id=cur.lastrowid,
          new_value={"invoice_id": iid, "amount": amount, "method": method,
                     "paid_after": paid, "outstanding_after": outstanding, "status": status})
    flash(f"Payment Rp {_money(amount)} recorded. Outstanding: Rp {_money(outstanding)} ({status}).", "success")
    return redirect(url_for("invoices.detail", iid=iid))


@INVOICE_BP.route("/<int:iid>/pdf")
@require_permission("invoice.view")
def pdf(iid):
    db = get_db()
    inv = db.execute("SELECT * FROM invoices WHERE invoice_id = ?", (iid,)).fetchone()
    if inv is None:
        abort(404)
    company = __import__("flask", fromlist=["current_app"]).current_app.config.get("COMPANY", {})
    payload = render_invoice_pdf(db, iid, company=company)
    return send_file(
        __import__("io").BytesIO(payload),
        mimetype="application/pdf",
        as_attachment=False,
        download_name=f"{inv['invoice_number']}.pdf",
    )


# ---------------------------------------------------------------------------
# low-level helpers
# ---------------------------------------------------------------------------
def _at(form, key, idx):
    values = form.getlist(key)
    return values[idx].strip() if idx < len(values) else ""


def _float_or(value, default):
    if value is None or value == "":
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _has(perm):
    from .auth import _user_has_perm

    return _user_has_perm(g.current_user, perm)


CATALOG_PRICE_BY_MATERIAL = {
    # material_id -> selling unit price (Rp) derived from docs/CATALOG_SOLA_2026.md.
    # Only confident family/price mappings included; others fall back to manual entry.
    33: 55000,   # CC-30S Cotton Combed 30s (T-Shirt incl. sablon)
    34: 60000,   # CC-24S Cotton Combed 24s
    35: 65000,   # CC-20S Cotton Combed 20s
    36: 50000,   # CD-30S Cotton Carded 30s
    37: 55000,   # CD-24S Cotton Carded 24s
    38: 60000,   # PQ-PE Piqe PE (Polo incl. bordir 2 posisi)
    39: 70000,   # PQ-CVC Piqe CVC
    40: 75000,   # PQ-CT Piqe Cotton
    41: 120000,  # DR-AM-KR American Drill (Korsa incl. lengan+4 bordir)
    42: 130000,  # DR-NT-KR Nagata Drill
    43: 135000,  # RB-PR-KR Ribstop Premium
    44: 120000,  # FL-PE Fleece PE (Hoodie incl. bordir/sablon 2)
    45: 135000,  # FL-CVC Fleece CVC
    46: 140000,  # FL-CT Fleece Cotton
    47: 135000,  # BT-CVC Baby Terry CVC
    48: 135000,  # BT-CT Baby Terry Cotton
    51: 135000,  # RB-PR-VS Ribstop Premium (Vest incl. bordir/sablon 2+zipper)
    52: 40000,   # RAFFLE (Cap incl. bordir 2 posisi)
    53: 20000,   # Mug Sublim (incl. sablon 2 warna + box)
    54: 18000,   # Mug Sablon
    55: 30000,   # Kanvas (Totebag 45x35 incl. sablon 2 warna + zipper)
    56: 24000,   # Tumbler A (incl. sablon 1 warna)
    57: 50000,   # Tumbler C
    62: 15000,   # Lanyard Only (Min. Order 24 pcs)
    63: 18000,   # Lanyard & ID Card
}


def _catalog_price(material_id):
    """Catalog selling price for a material_id, else None (fall back to manual)."""
    if not material_id:
        return None
    return CATALOG_PRICE_BY_MATERIAL.get(int(material_id))