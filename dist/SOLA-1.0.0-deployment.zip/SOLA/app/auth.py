"""Authentication + authorization (backend-enforced, spec §24 / §25.7).

Session-cookie based (Flask session). Roles and permissions are resolved from the
DB on every request — hiding a button is nowhere near enough; every protected
route re-checks the role/permission server-side (abort 403 / redirect to login).
"""
from functools import wraps

from flask import (
    Blueprint,
    abort,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash

from .db import audit, get_db

auth_bp = Blueprint("auth", __name__)

SESSION_USER_KEY = "sola_user_id"


def load_current_user():
    """Fetch the logged-in user (with role) for the current request; None if not authenticated."""
    uid = session.get(SESSION_USER_KEY)
    if not uid:
        return None
    db = get_db()
    return db.execute(
        "SELECT u.*, r.role_code, r.role_name FROM users u"
        " LEFT JOIN roles r ON u.role_id = r.role_id"
        " WHERE u.user_id = ? AND u.status = 'active'",
        (uid,),
    ).fetchone()


def _user_has_perm(user, *perms) -> bool:
    if user is None:
        return False
    placeholders = ",".join("?" * len(perms))
    db = get_db()
    row = db.execute(
        f"SELECT COUNT(*) AS n FROM role_permissions rp"
        f" JOIN permissions p ON p.permission_id = rp.permission_id"
        f" WHERE rp.role_id = ? AND p.permission_code IN ({placeholders})",
        (user["role_id"], *perms),
    ).fetchone()
    return bool(row and row["n"] > 0)


# ---------------------------------------------------------------------------
# Runtime gates (usable both as decorators and inline inside routes)
# ---------------------------------------------------------------------------
def assert_login():
    """Must be authenticated, else redirect to login preserving the next URL."""
    if g.get("current_user") is None:
        return redirect(url_for("auth.login", next=request.path))
    return None


def assert_permission(*perms):
    """Must be authenticated AND hold >=1 of the named permissions, else 403."""
    if g.get("current_user") is None:
        abort(403)
    if not _user_has_perm(g.current_user, *perms):
        abort(403)
    return None


def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        redirect_resp = assert_login()
        if redirect_resp is not None:
            return redirect_resp
        return f(*args, **kwargs)

    return wrapped


def require_role(*roles):
    """Restrict to one of the given role codes (e.g. require_role('ADMIN','MANAGEMENT'))."""

    def deco(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            u = g.get("current_user")
            if u is None:
                return redirect(url_for("auth.login", next=request.path))
            if u["role_code"] not in roles:
                abort(403)
            return f(*args, **kwargs)

        return wrapped

    return deco


def require_permission(*perms):
    """Restrict to a user holding >=1 of the given permission codes."""

    def deco(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            u = g.get("current_user")
            if u is None:
                return redirect(url_for("auth.login", next=request.path))
            if not _user_has_perm(u, *perms):
                abort(403)
            return f(*args, **kwargs)

        return wrapped

    return deco


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if g.get("current_user") is not None:
        return redirect(url_for("index"))
    error = None
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE username = ?", (username,)
        ).fetchone()
        if user is None or user["status"] != "active" or not check_password_hash(
            user["password_hash"] or "!", password
        ):
            error = "Invalid username or password."
        else:
            session.clear()
            session[SESSION_USER_KEY] = user["user_id"]
            audit(
                user["user_id"],
                "LOGIN",
                "session",
                entity_id=user["user_id"],
                new_value={"username": user["username"]},
            )
            nxt = request.args.get("next")
            if nxt and nxt.startswith("/") and not nxt.startswith("//"):
                return redirect(nxt)
            return redirect(url_for("index"))
    return render_template("login.html", error=error)


@auth_bp.route("/logout", methods=["GET", "POST"])
@login_required
def logout():
    uid = g.current_user["user_id"]
    try:
        audit(uid, "LOGOUT", "session", entity_id=uid)
    except Exception:
        pass
    session.clear()
    return redirect(url_for("auth.login"))