"""SOLA Phase 8 — Dashboard home (``/``): live KPI cards, alerts, deadlines & feed.

Built ON the verified Phases 0-7 app: reuses ``get_db()`` and the existing
tables (``orders``, ``invoices``, ``production_orders``, ``production_stages``,
``production_updates``, ``inventory``, ``users``, ``customers``) — **no DDL
change**. Every number derives from the live DB on every request (never
hard-coded). Status colors follow DESIGN_SPEC §1.1 tokens via the shared
``.badge`` / ``.progress`` classes.

KPI definitions (matching PHASE8_BRIEF §1 / DESIGN_SPEC §3.1):
  Active Orders       count of orders NOT completed/cancelled
  In Production       count of productions NOT completed/cancelled
  Waiting Payment     count of invoices with outstanding > 0
  Ready to Ship       productions at COMPLETED stage / status completed (no
                      "shipped" flag exists in the schema — documented boundary)
  Overdue             productions past deadline and not completed/cancelled
  Outstanding Invoice sum of invoices.outstanding (IDR)

Low-stock alert reuses the SAME threshold/semantics as the Inventory low-badge
(``inventory.LOW_STOCK_THRESHOLD``) so the two surfaces never disagree.
"""
from datetime import date

from flask import g, render_template

from .db import get_db
from .inventory import LOW_STOCK_THRESHOLD

BOARD_STAGES = [
    "ORDER",
    "MATERIAL PREPARATION",
    "CUTTING",
    "SEWING",
    "PRINTING",
    "FINISHING",
    "QC",
    "PACKING",
    "COMPLETED",
]


def _money(v):
    try:
        return f"{int(round(float(v or 0))):,}".replace(",", ".")
    except (TypeError, ValueError):
        return "0"


def compute_kpis(db):
    today = date.today().isoformat()
    active_orders = db.execute(
        "SELECT COUNT(*) AS n FROM orders"
        " WHERE status NOT IN ('completed','cancelled')"
    ).fetchone()["n"]
    in_production = db.execute(
        "SELECT COUNT(*) AS n FROM production_orders"
        " WHERE status NOT IN ('completed','cancelled')"
    ).fetchone()["n"]
    waiting_payment = db.execute(
        "SELECT COUNT(*) AS n FROM invoices WHERE outstanding > 0"
    ).fetchone()["n"]
    ready_to_ship = db.execute(
        "SELECT COUNT(*) AS n FROM production_orders"
        " WHERE (status='completed' OR current_stage='COMPLETED')"
        "   AND status != 'cancelled'"
    ).fetchone()["n"]
    overdue = db.execute(
        "SELECT COUNT(*) AS n FROM production_orders"
        " WHERE deadline IS NOT NULL AND deadline < ?"
        "   AND status NOT IN ('completed','cancelled')",
        (today,),
    ).fetchone()["n"]
    outstanding_sum = db.execute(
        "SELECT COALESCE(SUM(outstanding), 0) AS s FROM invoices"
    ).fetchone()["s"]
    kpis = [
        {"key": "active_orders", "label": "Active Orders", "value": active_orders,
         "token": "info", "link": "/orders", "sub": "not completed / cancelled"},
        {"key": "in_production", "label": "In Production", "value": in_production,
         "token": "warning", "link": "/production/", "sub": "jobs in the pipeline"},
        {"key": "waiting_payment", "label": "Waiting Payment", "value": waiting_payment,
         "token": "warning", "link": "/invoices/", "sub": "invoices with a balance"},
        {"key": "ready_to_ship", "label": "Ready to Ship", "value": ready_to_ship,
         "token": "success", "link": "/production/", "sub": "completed, not shipped"},
        {"key": "overdue", "label": "Overdue", "value": overdue,
         "token": "danger", "link": "/production/board", "sub": "past deadline"},
        {"key": "outstanding_invoice", "label": "Outstanding Invoice", "value": _money(outstanding_sum),
         "token": "danger", "link": "/invoices/", "sub": "sum owed (IDR)"},
    ]
    return kpis, {"outstanding_sum": outstanding_sum}


def compute_low_stock(db):
    """Tracked materials (rows present in inventory) at/below the low-stock threshold."""
    rows = db.execute(
        "SELECT i.material_id, m.material_code, m.material_name,"
        "       COALESCE(i.available, 0) AS available"
        " FROM inventory i"
        " JOIN materials m ON m.material_id = i.material_id"
        " WHERE m.status='active' AND COALESCE(i.available, 0) <= ?"
        " ORDER BY COALESCE(i.available, 0) ASC, m.material_name",
        (LOW_STOCK_THRESHOLD,),
    ).fetchall()
    return rows


def compute_upcoming_deadlines(db, limit=5):
    return db.execute(
        "SELECT production_id, production_code, deadline, quantity, current_stage"
        " FROM production_orders"
        " WHERE deadline IS NOT NULL AND status NOT IN ('completed','cancelled')"
        " ORDER BY deadline ASC, production_id ASC LIMIT ?",
        (limit,),
    ).fetchall()


def compute_unpaid_invoices(db):
    row = db.execute(
        "SELECT COUNT(*) AS n, COALESCE(SUM(outstanding), 0) AS total"
        " FROM invoices WHERE outstanding > 0"
    ).fetchone()
    return {"count": row["n"], "total": row["total"]}


def compute_recent_updates(db, limit=8):
    return db.execute(
        "SELECT u.update_id, u.production_id, u.progress, u.quantity_completed,"
        "       u.notes, u.timestamp, p.production_code,"
        "       u2.username AS actor, s.stage_name"
        " FROM production_updates u"
        " LEFT JOIN production_orders p ON p.production_id = u.production_id"
        " LEFT JOIN users u2 ON u2.user_id = u.user_id"
        " LEFT JOIN production_stages s ON s.production_stage_id = u.production_stage_id"
        " ORDER BY u.update_id DESC LIMIT ?",
        (limit,),
    ).fetchall()


def compute_board_snapshot(db):
    """Active productions bucketed by stage column -> count, for the mini bar chart."""
    rows = db.execute(
        "SELECT current_stage, COUNT(*) AS n FROM production_orders"
        " WHERE status NOT IN ('completed','cancelled')"
        " GROUP BY current_stage ORDER BY current_stage"
    ).fetchall()
    data = {st: 0 for st in BOARD_STAGES}
    for r in rows:
        stage = (r["current_stage"] or "").strip().upper()
        if stage == "MATERIAL":
            stage = "MATERIAL PREPARATION"
        if stage in data:
            data[stage] = r["n"]
    return data


def render_dashboard():
    """Build and render the real Phase-8 dashboard home (replaces the Phase-0 placeholder).

    Called from the app-level ``/`` route (endpoint ``index``) so ``url_for('index')``
    keeps resolving — the shared helper lives here to keep KPI/alert logic out of
    the app factory.
    """
    db = get_db()
    kpis, kpi_meta = compute_kpis(db)
    low_stock = compute_low_stock(db)
    deadlines = compute_upcoming_deadlines(db)
    unpaid = compute_unpaid_invoices(db)
    updates = compute_recent_updates(db)
    board_snapshot = compute_board_snapshot(db)
    low_threshold = LOW_STOCK_THRESHOLD
    try:
        from .production import COLUMN_TOKEN as _column_token
    except Exception:  # pragma: no cover - import guard only
        _column_token = {}
    return render_template(
        "dashboard.html",
        kpis=kpis,
        low_stock=low_stock,
        low_threshold=low_threshold,
        deadlines=deadlines,
        unpaid=unpaid,
        updates=updates,
        board_snapshot=board_snapshot,
        board_stages=BOARD_STAGES,
        column_token=_column_token,
        money=_money,
        current_username=(g.get("current_user")["username"] if g.get("current_user") else None),
    )