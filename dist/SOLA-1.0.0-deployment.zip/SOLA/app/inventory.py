"""SOLA Phase 6 — Inventory + Stock Movements (spec §18 / §24 / §27).

Built ON the Phase-2/3-4/5 app: reuses require_permission()/audit()/get_db()
and the EXISTING schema tables (inventory, stock_movements, material_usage,
materials, production_orders) — no DDL change.

Business rules enforced here (backend only, never UI-hiding alone):
- available = on_hand - reserved; a material with no inventory row is 0/0/0.
- ADJUSTMENT changes on_hand by a signed delta (guard: resulting on_hand must be
  >= reserved so available never goes negative).
- RESERVE moves qty into `reserved` (guard: qty <= available = on_hand - reserved).
- RELEASE (fulfillment, spec §18) moves qty from reserved to OUT: deducts on_hand
  AND clears reserved (guard: qty <= reserved).
- ISSUE (OUT) deducts on_hand directly (guard: qty <= on_hand, no over-issue).
- MATERIAL USAGE (recorded against a production) triggers an OUT movement + on_hand
  deduction (guard: qty <= on_hand), writes material_usage referencing production_id.
- Every accepted movement + every rejected/denied attempt is written to audit_logs
  and stock_movements (accepted). All on_hand/reserved arithmetic is done in a
  single request transaction (read-modify-write-commit on one connection) so a
  concurrent write cannot silently double-decrement.

Low stock: a material is LOW when available <= LOW_STOCK_THRESHOLD (module-level
default, simple per brief — deep Dashboard alerts are Phase 8).
"""
from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

from .auth import require_permission
from .db import audit, get_db

INV_BP = Blueprint("inventory", __name__, url_prefix="/inventory")

LOW_STOCK_THRESHOLD = 0          # available <= this  => low-stock warning badge
MOVEMENT_TYPES = ("IN", "OUT", "ADJUSTMENT", "RESERVED", "RELEASED")

_DEFAULT_UNIT = 1  # fallback unit id when neither inventory nor material have one (pcs)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _has(perm):
    from .auth import _user_has_perm

    return _user_has_perm(g.current_user, perm)


def _num(val, default=None):
    if val is None or str(val).strip() == "":
        return default
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def _int_or_none(val):
    if val is None or str(val).strip() in ("", "None"):
        return None
    try:
        return int(float(val))
    except (TypeError, ValueError):
        return None


def _material_unit(db, material_id, row=None):
    """Resolve a stable unit for a material (inventory row > material > fallback)."""
    if row is not None and row["unit_id"]:
        return row["unit_id"]
    m = db.execute(
        "SELECT unit_id FROM materials WHERE material_id=?", (material_id,)
    ).fetchone()
    if m and m["unit_id"]:
        return m["unit_id"]
    return _DEFAULT_UNIT


def _unit_label(db, unit_id):
    r = db.execute("SELECT unit_name FROM units WHERE unit_id=?", (unit_id,)).fetchone()
    return (r["unit_name"] if r else "") or ""


def _inv(db, material_id):
    """The single-valued inventory row for a material (created 0/0/0 if absent)."""
    row = db.execute(
        "SELECT * FROM inventory WHERE material_id=?", (material_id,)
    ).fetchone()
    if row is None:
        unit = _DEFAULT_UNIT
        m = db.execute(
            "SELECT unit_id FROM materials WHERE material_id=?", (material_id,)
        ).fetchone()
        if m and m["unit_id"]:
            unit = m["unit_id"]
        db.execute(
            "INSERT INTO inventory (material_id, unit_id, on_hand, reserved, available,"
            " location) VALUES (?,?,0,0,0,NULL)",
            (material_id, unit),
        )
        row = db.execute(
            "SELECT * FROM inventory WHERE material_id=?", (material_id,)
        ).fetchone()
    return row


def _movement(db, material_id, mtype, qty, unit_id, ref_type, ref_id, notes, user_id):
    cur = db.execute(
        "INSERT INTO stock_movements (material_id, movement_type, quantity, unit_id,"
        " reference_type, reference_id, moved_by, moved_at, notes)"
        " VALUES (?,?,?,?,?,?,?,datetime('now'),?)",
        (material_id, mtype, qty, unit_id, ref_type, ref_id, user_id, notes or None),
    )
    return cur.lastrowid


def _audit_denied(user_id, action, material_id, details):
    """Audit a REJECTED/guarded operation (spec §27 — attempts are auditable)."""
    audit(user_id, action, "inventory", entity_id=material_id, new_value=details)


def _is_low(available):
    return available is not None and available <= LOW_STOCK_THRESHOLD


def _materials_rows(db):
    """All active materials joined to their inventory row, with derived numbers."""
    rows = db.execute(
        "SELECT m.material_id, m.material_code, m.material_name, m.category,"
        "       m.specification, m.status, i.inventory_id, i.unit_id,"
        "       COALESCE(i.on_hand,0) AS on_hand, COALESCE(i.reserved,0) AS reserved,"
        "       COALESCE(i.location,'') AS location"
        " FROM materials m"
        " LEFT JOIN inventory i ON i.material_id = m.material_id"
        " WHERE m.status='active'"
        " ORDER BY m.material_name"
    ).fetchall()
    out = []
    for r in rows:
        r = dict(r)
        r["available"] = round(r["on_hand"] - r["reserved"], 4)
        r["low"] = _is_low(r["available"])
        r["unit_name"] = _unit_label(db, r["unit_id"] or _material_unit(db, r["material_id"]))
        out.append(r)
    return out


# ---------------------------------------------------------------------------
# LIST
# ---------------------------------------------------------------------------
@INV_BP.route("/")
@INV_BP.route("")
@require_permission("inventory.view")
def list_inventory():
    db = get_db()
    rows = _materials_rows(db)
    low_only = request.args.get("low") == "1"
    if low_only:
        rows = [r for r in rows if r["low"]]
    total_on_hand = round(sum(r["on_hand"] for r in _materials_rows(db)), 4)
    total_reserved = round(sum(r["reserved"] for r in _materials_rows(db)), 4)
    low_count = sum(1 for r in _materials_rows(db) if r["low"])
    return render_template(
        "inventory.html",
        rows=rows,
        low_only=low_only,
        low_threshold=LOW_STOCK_THRESHOLD,
        low_count=low_count,
        total_on_hand=total_on_hand,
        total_reserved=total_reserved,
        can_manage=_has("inventory.manage"),
        can_usage=_has("inventory.manage") or _has("production.manage"),
    )


# ---------------------------------------------------------------------------
# ADJUST
# ---------------------------------------------------------------------------
@INV_BP.route("/adjust", methods=["POST"])
@require_permission("inventory.manage")
def adjust():
    db = get_db()
    material_id = _int_or_none(request.form.get("material_id"))
    delta = _num(request.form.get("delta"))
    reason = (request.form.get("reason") or "").strip()
    if material_id is None or delta is None:
        flash("Material and a numeric delta are required.", "danger")
        return _back()
    m = db.execute("SELECT * FROM materials WHERE material_id=?", (material_id,)).fetchone()
    if m is None:
        abort(404)
    row = _inv(db, material_id)
    old_on_hand = row["on_hand"] or 0
    new_on_hand = round(old_on_hand + delta, 4)
    reserved = row["reserved"] or 0
    if new_on_hand < reserved:
        db.rollback()
        _audit_denied(g.current_user["user_id"], "ADJUST_DENIED", material_id, {
            "old_on_hand": old_on_hand, "requested_delta": delta,
            "reserved": reserved, "reason": reason or "",
            "message": "adjustment would push available below reserved stock",
        })
        flash("Cannot adjust below reserved stock (available must stay >= 0).", "danger")
        return _back()
    _movement(db, material_id, "ADJUSTMENT", delta, row["unit_id"], "adjustment",
              material_id, reason or f"Manual adjust by {g.current_user['username']}", g.current_user["user_id"])
    db.execute(
        "UPDATE inventory SET on_hand=?, reserved=?, available=?, unit_id=?,"
        " updated_at=datetime('now') WHERE material_id=?",
        (new_on_hand, reserved, round(new_on_hand - reserved, 4), row["unit_id"], material_id),
    )
    old_avail = round(old_on_hand - reserved, 4)
    new_avail = round(new_on_hand - reserved, 4)
    db.commit()
    audit(g.current_user["user_id"], "ADJUST", "inventory", entity_id=material_id,
          old_value={"on_hand": old_on_hand, "available": old_avail},
          new_value={"on_hand": new_on_hand, "reserved": reserved,
                     "available": new_avail, "delta": delta, "reason": reason})
    flash(f"Adjusted {m['material_code']} on_hand by {delta:g} → {new_on_hand:g}.", "success")
    return _back()


# ---------------------------------------------------------------------------
# RESERVE
# ---------------------------------------------------------------------------
@INV_BP.route("/reserve", methods=["POST"])
@require_permission("inventory.manage")
def reserve():
    db = get_db()
    material_id = _int_or_none(request.form.get("material_id"))
    qty = _num(request.form.get("quantity"))
    ref_type = (request.form.get("reference_type") or "order").strip()
    ref_id = _int_or_none(request.form.get("reference_id")) if ref_type != "order" else None
    notes = (request.form.get("notes") or "").strip()
    if material_id is None or qty is None or qty <= 0:
        flash("Material and a positive quantity are required.", "danger")
        return _back()
    m = db.execute("SELECT * FROM materials WHERE material_id=?", (material_id,)).fetchone()
    if m is None:
        abort(404)
    row = _inv(db, material_id)
    on_hand, reserved = row["on_hand"] or 0, row["reserved"] or 0
    available = round(on_hand - reserved, 4)
    if qty > available:
        db.rollback()
        _audit_denied(g.current_user["user_id"], "RESERVE_DENIED", material_id, {
            "requested": qty, "available": available, "on_hand": on_hand,
            "reserved": reserved, "message": "over-reserve rejected",
        })
        flash(f"Cannot reserve {qty:g}; only {available:g} available ({on_hand:g} on hand, {reserved:g} reserved).", "danger")
        return _back()
    new_reserved = round(reserved + qty, 4)
    _movement(db, material_id, "RESERVED", qty, row["unit_id"], ref_type, ref_id,
              notes or f"Reserve for {ref_type} ({material_id}) by {g.current_user['username']}", g.current_user["user_id"])
    db.execute(
        "UPDATE inventory SET reserved=?, available=?, updated_at=datetime('now')"
        " WHERE material_id=?",
        (new_reserved, round(on_hand - new_reserved, 4), material_id),
    )
    db.commit()
    audit(g.current_user["user_id"], "RESERVE", "inventory", entity_id=material_id,
          old_value={"reserved": reserved, "available": available},
          new_value={"reserved": new_reserved, "available": round(on_hand - new_reserved, 4),
                     "quantity": qty, "reference_type": ref_type, "reference_id": ref_id})
    flash(f"Reserved {qty:g} of {m['material_code']}.", "success")
    return _back()


# ---------------------------------------------------------------------------
# RELEASE (fulfillment -> OUT, clears reserved)
# ---------------------------------------------------------------------------
@INV_BP.route("/release", methods=["POST"])
@require_permission("inventory.manage")
def release():
    db = get_db()
    material_id = _int_or_none(request.form.get("material_id"))
    qty = _num(request.form.get("quantity"))
    notes = (request.form.get("notes") or "").strip()
    if material_id is None or qty is None or qty <= 0:
        flash("Material and a positive quantity are required.", "danger")
        return _back()
    m = db.execute("SELECT * FROM materials WHERE material_id=?", (material_id,)).fetchone()
    if m is None:
        abort(404)
    row = _inv(db, material_id)
    on_hand, reserved = row["on_hand"] or 0, row["reserved"] or 0
    if qty > reserved:
        db.rollback()
        _audit_denied(g.current_user["user_id"], "RELEASE_DENIED", material_id, {
            "requested": qty, "reserved": reserved, "message": "release exceeds reserved",
        })
        flash(f"Cannot release {qty:g}; only {reserved:g} reserved.", "danger")
        return _back()
    new_on_hand = round(on_hand - qty, 4)
    new_reserved = round(reserved - qty, 4)
    _movement(db, material_id, "RELEASED", qty, row["unit_id"], "order", material_id,
              notes or f"Release/fulfillment by {g.current_user['username']}", g.current_user["user_id"])
    db.execute(
        "UPDATE inventory SET on_hand=?, reserved=?, available=?, updated_at=datetime('now')"
        " WHERE material_id=?",
        (new_on_hand, new_reserved, round(new_on_hand - new_reserved, 4), material_id),
    )
    db.commit()
    audit(g.current_user["user_id"], "RELEASE", "inventory", entity_id=material_id,
          old_value={"on_hand": on_hand, "reserved": reserved},
          new_value={"on_hand": new_on_hand, "reserved": new_reserved,
                     "quantity": qty, "available": round(new_on_hand - new_reserved, 4)})
    flash(f"Released {qty:g} of {m['material_code']} (OUT, clears reserved).", "success")
    return _back()


# ---------------------------------------------------------------------------
# ISSUE (OUT) — manual deduction, over-issue guarded
# ---------------------------------------------------------------------------
@INV_BP.route("/issue", methods=["POST"])
@require_permission("inventory.manage")
def issue():
    db = get_db()
    material_id = _int_or_none(request.form.get("material_id"))
    qty = _num(request.form.get("quantity"))
    ref_type = (request.form.get("reference_type") or "order_item").strip()
    ref_id = _int_or_none(request.form.get("reference_id"))
    notes = (request.form.get("notes") or "").strip()
    if material_id is None or qty is None or qty <= 0:
        flash("Material and a positive quantity are required.", "danger")
        return _back()
    m = db.execute("SELECT * FROM materials WHERE material_id=?", (material_id,)).fetchone()
    if m is None:
        abort(404)
    row = _inv(db, material_id)
    on_hand = row["on_hand"] or 0
    if qty > on_hand:
        db.rollback()
        _audit_denied(g.current_user["user_id"], "ISSUE_DENIED", material_id, {
            "requested": qty, "on_hand": on_hand, "message": "over-issue rejected",
        })
        flash(f"Cannot issue {qty:g}; only {on_hand:g} on hand.", "danger")
        return _back()
    new_on_hand = round(on_hand - qty, 4)
    reserved = row["reserved"] or 0
    _movement(db, material_id, "OUT", qty, row["unit_id"], ref_type, ref_id,
              notes or f"Issue (OUT) by {g.current_user['username']}", g.current_user["user_id"])
    db.execute(
        "UPDATE inventory SET on_hand=?, reserved=?, available=?, updated_at=datetime('now')"
        " WHERE material_id=?",
        (new_on_hand, reserved, round(new_on_hand - reserved, 4), material_id),
    )
    db.commit()
    audit(g.current_user["user_id"], "ISSUE_OUT", "inventory", entity_id=material_id,
          old_value={"on_hand": on_hand},
          new_value={"on_hand": new_on_hand, "reserved": reserved,
                     "available": round(new_on_hand - reserved, 4), "quantity": qty,
                     "reference_type": ref_type, "reference_id": ref_id})
    flash(f"Issued {qty:g} of {m['material_code']} (OUT).", "success")
    return _back()


# ---------------------------------------------------------------------------
# MATERIAL USAGE (tied to a production -> OUT + material_usage)
# ---------------------------------------------------------------------------
@INV_BP.route("/usage", methods=["POST"])
@require_permission("inventory.manage", "production.manage")
def material_usage():
    db = get_db()
    material_id = _int_or_none(request.form.get("material_id"))
    production_id = _int_or_none(request.form.get("production_id"))
    qty = _num(request.form.get("quantity"))
    notes = (request.form.get("notes") or "").strip()
    if material_id is None or qty is None or qty <= 0:
        flash("Material and a positive quantity are required.", "danger")
        return _back()
    m = db.execute("SELECT * FROM materials WHERE material_id=?", (material_id,)).fetchone()
    if m is None:
        abort(404)
    prod = db.execute(
        "SELECT p.*, c.name AS customer_name FROM production_orders p"
        " LEFT JOIN orders o ON o.order_id=p.order_id"
        " LEFT JOIN customers c ON c.customer_id=o.customer_id"
        " WHERE p.production_id=?", (production_id,)
    ).fetchone() if production_id else None
    if prod is None:
        flash("Usage must reference an existing production.", "danger")
        return _back()
    row = _inv(db, material_id)
    on_hand = row["on_hand"] or 0
    if qty > on_hand:
        db.rollback()
        _audit_denied(g.current_user["user_id"], "USAGE_DENIED", material_id, {
            "requested": qty, "on_hand": on_hand, "production_id": production_id,
            "message": "material usage exceeds on_hand",
        })
        flash(f"Cannot consume {qty:g}; only {on_hand:g} on hand.", "danger")
        return _back()
    new_on_hand = round(on_hand - qty, 4)
    reserved = row["reserved"] or 0
    # OUT movement referencing the production + the material_usage record
    _movement(db, material_id, "OUT", qty, row["unit_id"], "production",
              production_id, notes or f"Material used on {prod['production_code']} by {g.current_user['username']}",
              g.current_user["user_id"])
    db.execute(
        "UPDATE inventory SET on_hand=?, reserved=?, available=?, updated_at=datetime('now')"
        " WHERE material_id=?",
        (new_on_hand, reserved, round(new_on_hand - reserved, 4), material_id),
    )
    cur = db.execute(
        "INSERT INTO material_usage (production_id, material_id, quantity, unit_id, used_at)"
        " VALUES (?,?,?,?,datetime('now'))",
        (production_id, material_id, qty, row["unit_id"]),
    )
    db.commit()
    audit(g.current_user["user_id"], "MATERIAL_USAGE", "inventory", entity_id=material_id,
          new_value={"production_id": production_id, "production_code": prod["production_code"],
                     "material_id": material_id, "quantity": qty,
                     "on_hand": new_on_hand, "material_usage_id": cur.lastrowid})
    flash(f"Recorded {qty:g} {m['material_code']} used on {prod['production_code']} (OUT).", "success")
    return _back()


# ---------------------------------------------------------------------------
# MOVEMENTS + USAGE LOG (view)
# ---------------------------------------------------------------------------
@INV_BP.route("/movements")
@require_permission("inventory.view")
def movements():
    db = get_db()
    mtype = (request.args.get("type") or "").strip().upper()
    q = request.args.get("q", "").strip()
    where, params = [], []
    if mtype in MOVEMENT_TYPES:
        where.append("sm.movement_type = ?")
        params.append(mtype)
    if q:
        where.append("(m.material_code LIKE ? OR m.material_name LIKE ? OR u.username LIKE ?)")
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    w = ("WHERE " + " AND ".join(where)) if where else ""
    rows = db.execute(
        f"SELECT sm.*, m.material_code, m.material_name, u.username, un.unit_name"
        f" FROM stock_movements sm"
        f" LEFT JOIN materials m ON m.material_id = sm.material_id"
        f" LEFT JOIN users u ON u.user_id = sm.moved_by"
        f" LEFT JOIN units un ON un.unit_id = sm.unit_id"
        f" {w} ORDER BY sm.stock_movement_id DESC LIMIT 300",
        params,
    ).fetchall()
    return render_template("inventory_movements.html", rows=rows, mtype=mtype, q=q,
                           movement_types=MOVEMENT_TYPES,
                           can_manage=_has("inventory.manage") or _has("production.manage"))


@INV_BP.route("/usage-log")
@require_permission("inventory.view")
def usage_log():
    db = get_db()
    rows = db.execute(
        "SELECT mu.*, m.material_code, m.material_name, p.production_code, un.unit_name"
        " FROM material_usage mu"
        " LEFT JOIN materials m ON m.material_id = mu.material_id"
        " LEFT JOIN production_orders p ON p.production_id = mu.production_id"
        " LEFT JOIN units un ON un.unit_id = mu.unit_id"
        " ORDER BY mu.material_usage_id DESC LIMIT 300"
    ).fetchall()
    return render_template("inventory_usage.html", rows=rows,
                           can_manage=_has("inventory.manage") or _has("production.manage"))


def _back():
    return redirect(url_for("inventory.list_inventory"))


@INV_BP.route("/productions")
@require_permission("inventory.manage", "production.manage")
def usage_productions():
    """JSON list of productions for the usage modal (reference picker)."""
    from flask import jsonify

    db = get_db()
    rows = db.execute(
        "SELECT p.production_id, p.production_code, c.name AS customer_name"
        " FROM production_orders p"
        " LEFT JOIN orders o ON o.order_id=p.order_id"
        " LEFT JOIN customers c ON c.customer_id=o.customer_id"
        " WHERE p.status NOT IN ('cancelled')"
        " ORDER BY p.production_id DESC LIMIT 100"
    ).fetchall()
    return jsonify([dict(r) for r in rows])