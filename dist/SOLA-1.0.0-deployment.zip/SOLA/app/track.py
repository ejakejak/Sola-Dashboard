"""SOLA Phase 7 — public customer production tracking (/track).

NO login required (intentionally NOT behind require_permission). A customer
enters a production_code (e.g. PRD-260922-001) and is shown ONLY that
production's customer-visible data.

Security (spec §20):
  * Lookup strictly by the unique production_code — no DB primary keys are ever
    emitted (no production_id / media_id / stage_id in the rendered page).
  * Any miss renders the SAME generic "Production not found." message — no
    existence oracle (we can't distinguish "code exists" from "wrong code").
  * Per-IP rate limiting (in-memory sliding window, constants in app/config.py):
      - at most 20 lookups / IP / hour,
      - after 5 consecutive failed lookups a 90s cooldown engages for that IP.
    Blocks return HTTP 429 with a generic message; rate-limit events are logged
    to the server log only (tracking is read-only public — no audit rows).
  * Customer-visible data ONLY. Never rendered: HPP/cost, margin, vendor price,
    internal notes, internal media (visibility == 'INTERNAL'), other customers'
    data, payment/invoice data.
  * CUSTOMER-visibility media is served through /track/media/<code>/<filename>
    which re-validates that the media row belongs to that production AND has
    visibility 'CUSTOMER' before sending bytes (INTERNAL media returns 404).
"""
import logging

from flask import (
    Blueprint,
    abort,
    current_app,
    render_template,
    request,
    send_from_directory,
)

from .config import BASE_DIR
from .db import get_db

log = logging.getLogger(__name__)

track_bp = Blueprint("track", __name__, url_prefix="/track")

UPLOAD_DIR = BASE_DIR / "app" / "static" / "uploads"

NOT_FOUND_MSG = "Production not found. Please check the code and try again."
RATE_LIMIT_MSG = (
    "Too many attempts. Please wait a few minutes and try again."
)
PROD_BADGE_CLASS = {
    "pending": "st-pending",
    "in_progress": "st-in_progress",
    "completed": "st-completed",
    "cancelled": "st-cancelled",
    "blocked": "st-partially_paid",
}


@track_bp.app_template_global()
def prod_badge_class(status):
    return PROD_BADGE_CLASS.get(status, "st-normal")


def _client_ip():
    return request.remote_addr or "unknown"


# ---------------------------------------------------------------------------
# Customer-visible data assembly
# ---------------------------------------------------------------------------
def _lookup_customer_view(db, code):
    """Return ONLY the customer-visible production fields (no row ids, no costs)."""
    prod = db.execute(
        """
        SELECT p.production_code, p.quantity, p.deadline, p.current_stage,
               p.overall_progress, p.status, p.notes,
               o.order_date, o.deadline AS order_deadline,
               COALESCE(pd.product_name, oi_pd.product_name) AS product_name,
               COALESCE(v.variant_name, oi_v.variant_name) AS variant_name
        FROM production_orders p
        LEFT JOIN orders o ON o.order_id = p.order_id
        LEFT JOIN order_items oi ON oi.order_item_id = p.order_item_id
        LEFT JOIN products pd ON pd.product_id = p.product_id
        LEFT JOIN products oi_pd ON oi_pd.product_id = oi.product_id
        LEFT JOIN product_variants v ON v.variant_id = p.variant_id
        LEFT JOIN product_variants oi_v ON oi_v.variant_id = oi.variant_id
        WHERE p.production_code = ?
        """,
        (code,),
    ).fetchone()
    if prod is None:
        return None
    # Production row PK could be NULL-injected via COALESCE; we never SELECT it.
    pid = db.execute(
        "SELECT production_id FROM production_orders WHERE production_code = ?",
        (code,),
    ).fetchone()["production_id"]
    stages = db.execute(
        "SELECT stage_name, sequence, status FROM production_stages"
        " WHERE production_id = ? ORDER BY sequence",
        (pid,),
    ).fetchall()
    latest = db.execute(
        "SELECT notes, progress, timestamp FROM production_updates"
        " WHERE production_id = ? ORDER BY update_id DESC LIMIT 1",
        (pid,),
    ).fetchone()
    media = db.execute(
        "SELECT file_url, file_type FROM production_media"
        " WHERE production_id = ? AND visibility = 'CUSTOMER'"
        " ORDER BY media_id DESC",
        (pid,),
    ).fetchall()
    return {
        "production_code": prod["production_code"],
        "product_name": prod["product_name"],
        "variant_name": prod["variant_name"],
        "quantity": prod["quantity"],
        "order_date": prod["order_date"],
        "order_deadline": prod["order_deadline"],
        "deadline": prod["deadline"],
        "current_stage": prod["current_stage"],
        "overall_progress": prod["overall_progress"],
        "status": prod["status"],
        "notes": prod["notes"],
        "stages": [dict(s) for s in stages],
        "latest_update": dict(latest) if latest else None,
        "media": [dict(m) for m in media],
    }


# ---------------------------------------------------------------------------
# Public routes
# ---------------------------------------------------------------------------
@track_bp.route("", methods=["GET", "POST"])
def track():
    limiter = current_app.extensions["rate_limiter"]
    ip = _client_ip()
    if request.method == "POST":
        code = (request.form.get("code") or "").strip()
        allowed, reason = limiter.allowed(ip)
        if not allowed:
            log.warning("rate-limit block ip=%s reason=%s", ip, reason)
            return render_template("public_track.html", data=None,
                                   message=RATE_LIMIT_MSG, alert_type="danger",
                                   code=code), 429
        limiter.record_lookup(ip)
        if not code:
            return render_template("public_track.html", data=None,
                                   message="Enter a production code to track.",
                                   alert_type="danger", code=code)
        view = _lookup_customer_view(get_db(), code)
        if view is None:
            limiter.record_failure(ip)
            return render_template("public_track.html", data=None,
                                   message=NOT_FOUND_MSG, alert_type="danger",
                                   code=code)
        limiter.record_success(ip)
        return render_template("public_track.html", data=view,
                               message=None, alert_type=None, code=code)
    return render_template("public_track.html", data=None,
                           message=None, alert_type=None, code="")


@track_bp.route("/media/<path:code>/<path:filename>")
def public_media(code, filename):
    """Serve ONLY CUSTOMER-visibility media for a validated production + media row.

    No DB primary key appears in the URL — the route re-checks that the media row
    belongs to ``code`` and has visibility 'CUSTOMER'; otherwise 404. This keeps
    INTERNAL media un-renderable and un-servable on any public surface.
    """
    db = get_db()
    prod = db.execute(
        "SELECT production_id FROM production_orders WHERE production_code = ?",
        (code,),
    ).fetchone()
    if prod is None:
        abort(404)
    media = db.execute(
        "SELECT media_id FROM production_media WHERE production_id = ?"
        " AND file_url = ? AND visibility = 'CUSTOMER'",
        (prod["production_id"], filename),
    ).fetchone()
    if media is None:
        abort(404)
    return send_from_directory(UPLOAD_DIR, filename)