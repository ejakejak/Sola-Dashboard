"""SOLA Phase 5 — configurable Workflow Templates + Production (spec §13-17).

Built ON the Phase-2/3-4 app: reuses require_permission() and audit() from
app.auth / app.db and the existing schema tables (production_workflow_templates,
production_workflow_template_steps, production_orders, production_stages,
production_updates, production_media, quality_checks) — no DDL change.

Business rules enforced here (backend):
- Production is created FROM an order (one production per order-item), resolving
  its stage list from a configurable workflow TEMPLATE (default garment), never a
  hard-coded workflow.
- production_code auto: PRD-<YYMMDD>-<NNN> sequential per day.
- overall_progress is DERIVED from stages (completed/total * 100), not manual.
- Stage lifecycle: pending -> in_progress -> completed (with target/completed/
  rejected qty + start_at/completed_at); blocked/cancelled supported.
- production_updates record progress/qty/notes per (user,timestamp).
- production_media has visibility INTERNAL|CUSTOMER (default INTERNAL in DB).
  INTERNAL media is served/listed ONLY to roles holding production.media.internal.read
  and NEVER on any customer surface; CUSTOMER media is visible to all production.view
  holders. Gating is backend-enforced at the serve route, not just hidden buttons.
- quality_checks record pass/fail/rework with qty + defect + evidence; on rework
  the production can be returned to a chosen earlier stage.
- Every create/status/update/media/QC write is audited via audit().

Media files are saved under app/static/uploads/ (gitignored) and served through a
permission-gated route (no direct static exposure).
"""
import os
from datetime import date, datetime
from pathlib import Path

from flask import (
    Blueprint,
    abort,
    flash,
    g,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)
from werkzeug.utils import secure_filename

from .auth import require_permission
from .db import audit, get_db
from .config import BASE_DIR

PROD_BP = Blueprint("production", __name__, url_prefix="/production")

STAGE_STATUSES = ["pending", "in_progress", "completed", "blocked", "cancelled"]
PROD_STATUSES = ["in_progress", "completed", "blocked", "cancelled"]
MEDIA_VISIBILITY = ["INTERNAL", "CUSTOMER"]  # default INTERNAL (DB default)
QC_STATUSES = ["passed", "failed", "rework"]

# Phase 8 — Production Kanban board (DESIGN_SPEC §3.2). Fixed 9 columns in order.
BOARD_COLUMNS = [
    "ORDER",
    "MATERIAL PREPARATION",
    "CUTTING",
    "SEWING",
    "PRINTING",
    "FINISHING",
    "QC",
    "PACKING",
    "COMPLETED",
]

# current_stage -> canonical column (case-insensitive). Covers the garment-default
# template verbatim plus the short "MATERIAL" alias from the Topi template.
STAGE_TO_COLUMN = {s.upper(): s for s in BOARD_COLUMNS}
STAGE_TO_COLUMN["MATERIAL"] = "MATERIAL PREPARATION"
STAGE_TO_COLUMN["COMPLETED"] = "COMPLETED"

# token per column for the header count badge / accents (DESIGN_SPEC §3.2).
COLUMN_TOKEN = {
    "ORDER": "neutral",
    "MATERIAL PREPARATION": "info",
    "CUTTING": "info",
    "SEWING": "warning",
    "PRINTING": "warning",
    "FINISHING": "warning",
    "QC": "info",
    "PACKING": "warning",
    "COMPLETED": "success",
}


def _board_column(stage, status):
    """Bucket a production row into a BOARD_COLUMNS column.

    Fallback per PHASE8_BRIEF §2: exact/aliased current_stage wins; else the row
    status decides — completed -> COMPLETED, cancelled -> None (excluded from the
    board); an unmapped in-progress stage has no column and lands in ``other``.
    """
    stg = (stage or "").strip().upper()
    if stg in STAGE_TO_COLUMN:
        return STAGE_TO_COLUMN[stg]
    if status == "completed":
        return "COMPLETED"
    if status == "cancelled":
        return None
    return "__other__"

UPLOAD_DIR = BASE_DIR / "app" / "static" / "uploads"


def _money(v):
    try:
        return f"{int(round(float(v or 0))):,}".replace(",", ".")
    except (TypeError, ValueError):
        return "0"


def _today_ymd():
    return date.today().strftime("%y%m%d")


def _next_production_code(db):
    """PRD-<YYMMDD>-<NNN> sequential per day."""
    prefix = f"PRD-{_today_ymd()}-"
    rows = db.execute(
        "SELECT production_code FROM production_orders WHERE production_code LIKE ?",
        (prefix + "%",),
    ).fetchall()
    highest = 0
    for r in rows:
        tail = r["production_code"].rsplit("-", 1)[-1]
        if tail.isdigit():
            highest = max(highest, int(tail))
    return f"{prefix}{highest + 1:03d}"


def _has(perm):
    from .auth import _user_has_perm

    return _user_has_perm(g.current_user, perm)


def _default_template(db):
    """The garment 'default' template (catch-all is_default) or the first active one."""
    row = db.execute(
        "SELECT * FROM production_workflow_templates"
        " WHERE status='active' AND is_default=1"
        " ORDER BY workflow_template_id LIMIT 1",
    ).fetchone()
    if row is None:
        row = db.execute(
            "SELECT * FROM production_workflow_templates WHERE status='active'"
            " ORDER BY workflow_template_id LIMIT 1",
        ).fetchone()
    return row


def _template_steps(db, template_id):
    return db.execute(
        "SELECT * FROM production_workflow_template_steps"
        " WHERE workflow_template_id = ? ORDER BY sequence",
        (template_id,),
    ).fetchall()


def _recompute_production(db, pid):
    """Recompute overall_progress + current_stage + top-level status from stages."""
    prod = db.execute(
        "SELECT * FROM production_orders WHERE production_id = ?", (pid,)
    ).fetchone()
    if prod is None:
        return
    stages = db.execute(
        "SELECT * FROM production_stages WHERE production_id = ? ORDER BY sequence",
        (pid,),
    ).fetchall()
    total = len(stages)
    completed = sum(1 for s in stages if s["status"] == "completed")
    cancelled = sum(1 for s in stages if s["status"] == "cancelled")
    blocked = sum(1 for s in stages if s["status"] == "blocked")
    progress = round((completed / total) * 100, 1) if total else 0.0

    current_stage = prod["current_stage"]
    for s in stages:
        if s["status"] not in ("completed", "cancelled"):
            current_stage = s["stage_name"]
            break
    else:
        current_stage = stages[-1]["stage_name"] if stages else current_stage

    if cancelled == total and total:
        status = "cancelled"
    elif blocked > 0:
        status = "blocked"
    elif completed == total and total:
        status = "completed"
    else:
        status = "in_progress"

    db.execute(
        "UPDATE production_orders SET overall_progress=?, current_stage=?, status=?,"
        " updated_at=datetime('now') WHERE production_id=?",
        (progress, current_stage, status, pid),
    )


def _stage_progress_bar(stage):
    """Derive a single stage's completion % from completed_quantity/target_quantity."""
    if stage["completed_quantity"] and stage["target_quantity"]:
        try:
            return round(
                float(stage["completed_quantity"]) / float(stage["target_quantity"]) * 100, 0
            )
        except (ZeroDivisionError, ValueError, TypeError):
            return 0
    if stage["status"] == "completed":
        return 100
    return 0


# ---------------------------------------------------------------------------
# WORKFLOW TEMPLATES
# ---------------------------------------------------------------------------
@PROD_BP.route("/templates")
@require_permission("workflow.manage")
def template_list():
    db = get_db()
    rows = db.execute(
        "SELECT t.*, c.category_name,"
        " (SELECT COUNT(*) FROM production_workflow_template_steps s"
        "  WHERE s.workflow_template_id = t.workflow_template_id) AS step_count"
        " FROM production_workflow_templates t"
        " LEFT JOIN product_categories c ON c.category_id = t.product_category_id"
        " ORDER BY t.is_default DESC, t.workflow_template_id"
    ).fetchall()
    return render_template(
        "workflow_template_list.html", templates=rows, can_manage=_has("workflow.manage")
    )


@PROD_BP.route("/templates/new", methods=["GET", "POST"])
@require_permission("workflow.manage")
def template_new():
    db = get_db()
    categories = db.execute(
        "SELECT category_id, category_name FROM product_categories ORDER BY category_name"
    ).fetchall()
    if request.method == "POST":
        name = (request.form.get("template_name") or "").strip()
        category_id = request.form.get("product_category_id") or None
        is_default = 1 if request.form.get("is_default") else 0
        if not name:
            flash("Template name is required.", "danger")
        else:
            category_id = int(category_id) if category_id else None
            cur = db.execute(
                "INSERT INTO production_workflow_templates"
                " (template_name, product_category_id, is_default, status)"
                " VALUES (?,?,?, 'active')",
                (name, category_id, is_default),
            )
            tid = cur.lastrowid
            _save_steps(db, tid, request)
            audit(g.current_user["user_id"], "CREATE", "workflow_template",
                  entity_id=tid, new_value={"template_name": name})
            flash(f"Workflow template '{name}' created.", "success")
            return redirect(url_for("production.template_edit", tid=tid))
    return render_template("workflow_template_form.html", category_options=categories,
                           t=None, steps=[], form=dict(request.form))


@PROD_BP.route("/templates/<int:tid>/edit", methods=["GET", "POST"])
@require_permission("workflow.manage")
def template_edit(tid):
    db = get_db()
    t = db.execute(
        "SELECT * FROM production_workflow_templates WHERE workflow_template_id=?",
        (tid,),
    ).fetchone()
    if t is None:
        abort(404)
    categories = db.execute(
        "SELECT category_id, category_name FROM product_categories ORDER BY category_name"
    ).fetchall()
    steps = db.execute(
        "SELECT * FROM production_workflow_template_steps WHERE workflow_template_id=?"
        " ORDER BY sequence",
        (tid,),
    ).fetchall()
    if request.method == "POST":
        name = (request.form.get("template_name") or "").strip()
        category_id = request.form.get("product_category_id") or None
        is_default = 1 if request.form.get("is_default") else 0
        if not name:
            flash("Template name is required.", "danger")
        else:
            category_id = int(category_id) if category_id else None
            old = {"template_name": t["template_name"], "is_default": t["is_default"]}
            db.execute(
                "UPDATE production_workflow_templates SET template_name=?,"
                " product_category_id=?, is_default=? WHERE workflow_template_id=?",
                (name, category_id, is_default, tid),
            )
            # full step-set replace (sequence deterministic from the form)
            db.execute(
                "DELETE FROM production_workflow_template_steps WHERE workflow_template_id=?",
                (tid,),
            )
            _save_steps(db, tid, request)
            db.commit()
            audit(g.current_user["user_id"], "UPDATE", "workflow_template", entity_id=tid,
                  old_value=old,
                  new_value={"template_name": name, "is_default": is_default})
            flash(f"Workflow template '{name}' updated.", "success")
            return redirect(url_for("production.template_list"))
    return render_template("workflow_template_form.html", category_options=categories,
                           t=t, steps=steps, form=dict(request.form))


def _save_steps(db, tid, req):
    names = req.form.getlist("step_name[]")
    seq = 1
    last = None
    for raw in names:
        stage_name = (raw or "").strip()
        if not stage_name:
            continue
        last = stage_name
        seq = seq
        db.execute(
            "INSERT OR REPLACE INTO production_workflow_template_steps"
            " (workflow_template_id, sequence, stage_name, is_completion)"
            " VALUES (?,?,?,0)",
            (tid, seq, stage_name),
        )
        seq += 1
    # mark the final step as the completion gate
    if last is not None:
        db.execute(
            "UPDATE production_workflow_template_steps SET is_completion=1"
            " WHERE workflow_template_id=? AND stage_name=?",
            (tid, last),
        )
    db.commit()


# ---------------------------------------------------------------------------
# PRODUCTION LIST / BOARD
# ---------------------------------------------------------------------------
@PROD_BP.route("/")
@require_permission("production.view")
def list_productions():
    db = get_db()
    q = request.args.get("q", "").strip()
    rows = db.execute(
        f"""
        SELECT p.*, o.order_number, c.name AS customer_name, o.deadline AS order_deadline
        FROM production_orders p
        LEFT JOIN orders o ON o.order_id = p.order_id
        LEFT JOIN customers c ON c.customer_id = o.customer_id
        {("WHERE p.production_code LIKE ? OR o.order_number LIKE ? OR c.name LIKE ?"
          if q else "")}
        ORDER BY p.production_id DESC
        """,
        ([f"%{q}%", f"%{q}%", f"%{q}%"] if q else []),
    ).fetchall()
    return render_template("production_list.html", rows=rows, q=q,
                           can_manage=_has("production.manage"))


def _days_left(deadline):
    if not deadline:
        return None
    try:
        d = date.fromisoformat(str(deadline)[:10])
    except ValueError:
        return None
    return (d - date.today()).days


@PROD_BP.route("/board")
@require_permission("production.view")
def board():
    db = get_db()
    rows = db.execute(
        """
        SELECT p.production_id, p.production_code, p.quantity, p.deadline,
               p.current_stage, p.overall_progress, p.status, p.notes,
               p.created_at, p.updated_at, o.order_number,
               COALESCE(o.priority, 'normal') AS priority,
               o.deadline AS order_deadline, c.name AS customer_name,
               pr.product_name,
               (SELECT u.username FROM production_stages s
                  LEFT JOIN users u ON u.user_id = s.assigned_user
                 WHERE s.production_id = p.production_id
                   AND s.status IN ('in_progress','blocked')
                 ORDER BY s.sequence LIMIT 1) AS pic_name
        FROM production_orders p
        LEFT JOIN orders o ON o.order_id = p.order_id
        LEFT JOIN customers c ON c.customer_id = o.customer_id
        LEFT JOIN products pr ON pr.product_id = p.product_id
        ORDER BY p.production_id
        """
    ).fetchall()
    buckets = {name: [] for name in BOARD_COLUMNS}
    other = []
    for raw in rows:
        r = dict(raw)
        col = _board_column(r["current_stage"], r["status"])
        r["days_left"] = _days_left(r["deadline"] or r["order_deadline"])
        r["overdue"] = bool(r["days_left"] is not None and r["days_left"] < 0
                            and r["status"] not in ("completed", "cancelled"))
        if col in buckets:
            buckets[col].append(r)
        elif col == "__other__":
            other.append(r)
        # col is None (cancelled) -> omitted from the board
    all_prods = [r for col in BOARD_COLUMNS for r in buckets[col]] + other
    return render_template(
        "production_board.html",
        columns=buckets,
        other=other,
        all_prods=all_prods,
        board_columns=BOARD_COLUMNS,
        column_token=COLUMN_TOKEN,
        can_manage=_has("production.manage"),
        total=len(all_prods),
    )


# ---------------------------------------------------------------------------
# PRODUCTION FROM ORDER
# ---------------------------------------------------------------------------
@PROD_BP.route("/from-order")
@require_permission("production.manage")
def from_order_form():
    db = get_db()
    orders = db.execute(
        "SELECT o.*, c.name AS customer_name FROM orders o"
        " LEFT JOIN customers c ON c.customer_id = o.customer_id"
        " WHERE o.status NOT IN ('cancelled') ORDER BY o.order_id DESC"
    ).fetchall()
    templates = db.execute(
        "SELECT * FROM production_workflow_templates WHERE status='active'"
        " ORDER BY is_default DESC, workflow_template_id"
    ).fetchall()
    return render_template("production_from_order.html", orders=orders,
                           templates=templates)


@PROD_BP.route("/from-order/<int:oid>", methods=["POST"])
@require_permission("production.manage")
def create_from_order(oid):
    """Create ONE production per order-item from the chosen order + template."""
    db = get_db()
    o = db.execute("SELECT * FROM orders WHERE order_id = ?", (oid,)).fetchone()
    if o is None:
        abort(404)
    template_id = request.form.get("template_id") or None
    template = db.execute(
        "SELECT * FROM production_workflow_templates WHERE workflow_template_id=?",
        (int(template_id) if template_id else -1,),
    ).fetchone() if template_id else _default_template(db)
    if template is None:
        flash("No workflow template available. Seed templates first.", "danger")
        return redirect(url_for("production.list_productions"))
    items = db.execute(
        "SELECT * FROM order_items WHERE order_id = ?", (oid,)
    ).fetchall()
    if not items:
        flash("Order has no line items; cannot create production.", "danger")
        return redirect(url_for("production.list_productions"))
    steps = _template_steps(db, template["workflow_template_id"])
    if not steps:
        flash("Template has no steps; cannot materialize production.", "danger")
        return redirect(url_for("production.list_productions"))

    created_codes = []
    for oi in items:
        code = _next_production_code(db)
        cur = db.execute(
            "INSERT INTO production_orders"
            " (production_code, order_id, order_item_id, product_id, variant_id,"
            "  quantity, deadline, current_stage, overall_progress, status,"
            "  workflow_template_id, notes)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (code, oid, oi["order_item_id"], oi["product_id"], oi["variant_id"],
             oi["quantity"], o["deadline"], steps[0]["stage_name"], 0.0,
             "in_progress", template["workflow_template_id"],
             request.form.get("notes") or None),
        )
        pid = cur.lastrowid
        for st in steps:
            db.execute(
                "INSERT INTO production_stages"
                " (production_id, stage_id, stage_name, sequence, status, target_quantity)"
                " VALUES (?,?,?,?,?,?)",
                (pid, st["workflow_template_step_id"], st["stage_name"], st["sequence"],
                 "pending", oi["quantity"]),
            )
        _recompute_production(db, pid)
        audit(g.current_user["user_id"], "CREATE", "production_order", entity_id=pid,
              new_value={"production_code": code, "order_id": oid,
                         "workflow_template_id": template["workflow_template_id"],
                         "quantity": oi["quantity"]})
        created_codes.append(code)
    db.commit()
    flash(f"Production created from order {o['order_number']}: "
          f"{', '.join(created_codes)}.", "success")
    return redirect(url_for("production.list_productions"))


# ---------------------------------------------------------------------------
# PRODUCTION DETAIL
# ---------------------------------------------------------------------------
@PROD_BP.route("/<int:pid>")
@require_permission("production.view")
def detail(pid):
    db = get_db()
    p = db.execute(
        "SELECT p.*, o.order_number, c.name AS customer_name, c.company_name,"
        "       o.deadline AS order_deadline"
        " FROM production_orders p"
        " LEFT JOIN orders o ON o.order_id = p.order_id"
        " LEFT JOIN customers c ON c.customer_id = o.customer_id"
        " WHERE p.production_id = ?",
        (pid,),
    ).fetchone()
    if p is None:
        abort(404)
    stages = db.execute(
        """
        SELECT s.*, u.username AS pic_name, v.vendor_name
        FROM production_stages s
        LEFT JOIN users u ON u.user_id = s.assigned_user
        LEFT JOIN vendors v ON v.vendor_id = s.assigned_vendor
        WHERE s.production_id = ? ORDER BY s.sequence
        """,
        (pid,),
    ).fetchall()
    updates = db.execute(
        "SELECT u.*, usr.username FROM production_updates u"
        " LEFT JOIN users usr ON usr.user_id = u.user_id"
        " WHERE u.production_id = ? ORDER BY u.update_id DESC",
        (pid,),
    ).fetchall()
    can_internal = _has("production.media.internal.read")
    # INTERNAL media gated here (backend) — served through a gated route too.
    media = db.execute(
        "SELECT * FROM production_media WHERE production_id = ?"
        " AND (visibility='CUSTOMER' OR ?) ORDER BY media_id DESC",
        (pid, 1 if can_internal else 0),
    ).fetchall()
    qcs = db.execute(
        "SELECT q.*, usr.username AS inspector_name FROM quality_checks q"
        " LEFT JOIN users usr ON usr.user_id = q.inspector"
        " WHERE q.production_id = ? ORDER BY q.qc_id DESC",
        (pid,),
    ).fetchall()
    template = db.execute(
        "SELECT * FROM production_workflow_templates WHERE workflow_template_id=?",
        (p["workflow_template_id"],),
    ).fetchone()
    return render_template(
        "production_detail.html",
        p=p, stages=stages, updates=updates, media=media, qcs=qcs, template=template,
        stage_statuses=STAGE_STATUSES, media_visibility=MEDIA_VISIBILITY,
        can_manage=_has("production.manage"), can_update=_has("production.update"),
        can_internal=can_internal, can_qc=_has("qc.manage"),
        view_others=stages,  # placeholder for stage-progress mapping
        stage_progress={s["production_stage_id"]: _stage_progress_bar(s) for s in stages},
    )


@PROD_BP.route("/<int:pid>/stage/<int:sid>/advance", methods=["POST"])
@require_permission("production.manage")
def advance_stage(pid, sid):
    db = get_db()
    stage = db.execute(
        "SELECT * FROM production_stages WHERE production_stage_id=? AND production_id=?",
        (sid, pid),
    ).fetchone()
    if stage is None:
        abort(404)
    status = request.form.get("status") or stage["status"]
    if status not in STAGE_STATUSES:
        flash("Invalid stage status.", "danger")
        return redirect(url_for("production.detail", pid=pid))

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    fields = []
    params = []
    old = {"status": stage["status"]}

    # assignment + quantities always applied from form
    assigned_user = request.form.get("assigned_user") or stage["assigned_user"]
    assigned_vendor = request.form.get("assigned_vendor") or stage["assigned_vendor"]
    target = _f(request.form.get("target_quantity"), stage["target_quantity"])
    completed = _f(request.form.get("completed_quantity"), stage["completed_quantity"])
    rejected = _f(request.form.get("rejected_quantity"), stage["rejected_quantity"])
    notes = request.form.get("notes") or stage["notes"]

    fields += ["assigned_user=?", "assigned_vendor=?", "target_quantity=?",
               "completed_quantity=?", "rejected_quantity=?", "notes=?"]
    params += [assigned_user, assigned_vendor, target, completed, rejected, notes]

    if status == "in_progress" and stage["status"] in ("pending", "blocked"):
        fields.append("start_at=?")
        params.append(now)
        # any earlier pending stage that was skipped is set to cancelled to keep
        # the timeline sequential unless it was already in_progress/completed.
        db.execute(
            "UPDATE production_stages SET status='cancelled' WHERE production_id=?"
            " AND sequence < ? AND status='pending'",
            (pid, stage["sequence"]),
        )
    elif status == "completed":
        fields.append("start_at=COALESCE(start_at, ?)")
        params.append(now)
        fields.append("completed_at=?")
        params.append(now)
    elif status == "blocked":
        fields.append("completed_at=NULL")
    fields.append("status=?")
    params.append(status)
    params.append(sid)

    db.execute(
        f"UPDATE production_stages SET {', '.join(fields)} WHERE production_stage_id=?",
        params,
    )
    _recompute_production(db, pid)
    db.commit()
    audit(g.current_user["user_id"], "UPDATE", "production_stage", entity_id=sid,
          old_value=old, new_value={"status": status, "stage": stage["stage_name"]})
    flash(f"Stage '{stage['stage_name']}' → {status}.", "success")
    return redirect(url_for("production.detail", pid=pid))


def _f(val, default):
    if val is None or str(val).strip() == "":
        return default
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# PRODUCTION UPDATES
# ---------------------------------------------------------------------------
@PROD_BP.route("/<int:pid>/updates", methods=["POST"])
@require_permission("production.manage")
def add_update(pid):
    db = get_db()
    p = db.execute("SELECT * FROM production_orders WHERE production_id=?", (pid,)).fetchone()
    if p is None:
        abort(404)
    progress = request.form.get("progress") or None
    if progress is not None:
        progress = max(0.0, min(100.0, float(progress or 0)))
    qty_completed = request.form.get("quantity_completed") or None
    qty_rejected = request.form.get("quantity_rejected") or None
    notes = request.form.get("notes") or None
    stage_id = request.form.get("production_stage_id") or None
    cur = db.execute(
        "INSERT INTO production_updates (production_id, production_stage_id, user_id,"
        " progress, quantity_completed, quantity_rejected, notes)"
        " VALUES (?,?,?,?,?,?,?)",
        (pid, int(stage_id) if stage_id else None, g.current_user["user_id"],
         progress, qty_completed, qty_rejected, notes),
    )
    db.commit()
    audit(g.current_user["user_id"], "CREATE", "production_update",
          entity_id=cur.lastrowid,
          new_value={"production_id": pid, "progress": progress, "qty_completed": qty_completed})
    flash("Production update recorded.", "success")
    return redirect(url_for("production.detail", pid=pid))


# ---------------------------------------------------------------------------
# PRODUCTION MEDIA (visibility-gated)
# ---------------------------------------------------------------------------
def _upload_dir():
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    return UPLOAD_DIR


@PROD_BP.route("/<int:pid>/media", methods=["POST"])
@require_permission("production.manage")
def upload_media(pid):
    db = get_db()
    p = db.execute("SELECT * FROM production_orders WHERE production_id=?", (pid,)).fetchone()
    if p is None:
        abort(404)
    file = request.files.get("file")
    visibility = request.form.get("visibility") or "INTERNAL"
    if visibility not in MEDIA_VISIBILITY:
        visibility = "INTERNAL"
    if file is None or not file.filename:
        flash("Choose a file to upload.", "danger")
        return redirect(url_for("production.detail", pid=pid))

    fn = secure_filename(file.filename) or "upload.bin"
    ext = Path(fn).suffix.lower()
    ftype = "video" if ext in (".mp4", ".mov", ".webm", ".avi", ".mkv") else "image"
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    stored = f"prod_{pid}_{stamp}_{fn}"
    _upload_dir()
    file.save(UPLOAD_DIR / stored)
    file_url = url_for("production.media_file", mid=0).rsplit("/0", 1)[0] + f"/{pid}_{stamp}_{fn}"
    cur = db.execute(
        "INSERT INTO production_media (production_id, file_url, file_type, visibility,"
        " uploaded_by) VALUES (?,?,?,?,?)",
        (pid, stored, ftype, visibility, g.current_user["user_id"]),
    )
    db.commit()
    audit(g.current_user["user_id"], "CREATE", "production_media",
          entity_id=cur.lastrowid,
          new_value={"production_id": pid, "visibility": visibility, "file_type": ftype})
    flash(f"Media uploaded ({visibility}).", "success")
    return redirect(url_for("production.detail", pid=pid))


@PROD_BP.route("/media/<int:mid>/file")
@require_permission("production.view")
def media_file(mid):
    db = get_db()
    m = db.execute("SELECT * FROM production_media WHERE media_id=?", (mid,)).fetchone()
    if m is None:
        abort(404)
    # BACKEND gate: INTERNAL media requires the internal-read permission.
    if m["visibility"] == "INTERNAL" and not _has("production.media.internal.read"):
        abort(403)
    _upload_dir()
    return send_from_directory(UPLOAD_DIR, m["file_url"])


# ---------------------------------------------------------------------------
# QC
# ---------------------------------------------------------------------------
@PROD_BP.route("/<int:pid>/qc", methods=["POST"])
@require_permission("qc.manage")
def record_qc(pid):
    db = get_db()
    p = db.execute("SELECT * FROM production_orders WHERE production_id=?", (pid,)).fetchone()
    if p is None:
        abort(404)
    status = request.form.get("status") or "passed"
    if status not in QC_STATUSES:
        status = "passed"
    passed = request.form.get("passed_quantity") or None
    rejected = request.form.get("rejected_quantity") or None
    defect = request.form.get("defect_type") or None
    notes = request.form.get("notes") or None
    evidence = request.form.get("evidence") or None
    stage_id = request.form.get("stage_id") or None
    stage_id = int(stage_id) if stage_id else None

    cur = db.execute(
        "INSERT INTO quality_checks (production_id, stage_id, inspector,"
        " passed_quantity, rejected_quantity, defect_type, notes, status, evidence)"
        " VALUES (?,?,?,?,?,?,?,?,?)",
        (pid, stage_id, g.current_user["user_id"], passed, rejected, defect, notes,
         status, evidence),
    )

    # On rework, allow returning the production to a chosen earlier stage.
    if status == "rework" and request.form.get("return_stage_id"):
        return_sid = int(request.form["return_stage_id"])
        db.execute(
            "UPDATE production_stages SET status='in_progress',"
            " completed_at=NULL, start_at=COALESCE(start_at, datetime('now'))"
            " WHERE production_stage_id=? AND production_id=?",
            (return_sid, pid),
        )
        # any stages after the return point that were completed get re-opened
        db.execute(
            "UPDATE production_stages SET status='pending', completed_at=NULL"
            " WHERE production_id=? AND sequence >"
            " (SELECT sequence FROM production_stages WHERE production_stage_id=?)"
            " AND status='completed'",
            (pid, return_sid),
        )
    _recompute_production(db, pid)
    db.commit()
    audit(g.current_user["user_id"], "CREATE", "quality_check", entity_id=cur.lastrowid,
          new_value={"production_id": pid, "status": status, "stage_id": stage_id,
                     "passed": passed, "rejected": rejected})
    flash(f"QC recorded as {status}.", "success")
    return redirect(url_for("production.detail", pid=pid))